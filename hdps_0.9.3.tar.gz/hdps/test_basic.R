#!/usr/bin/env Rscript
# Basic functionality test for HDPS package

library(hdps)
library(data.table)

# Load test data
data(dx)
data(master)

cat("Testing HDPS package functionality...\n\n")

# Test 1: Basic hdps function
cat("Test 1: Basic hdps function\n")
cat("-------------------------\n")

tryCatch({
    results <- hdps(
        data = dx,
        id_col = "pid",
        code_col = "icd9code", 
        exposure_col = "exposure",
        outcome_col = "outcome",
        master_data = master,
        n_candidates = 50,
        min_patients = 5,
        n_cores = 1  # Use single core for testing
    )
    
    cat("✅ hdps() function works\n")
    cat(sprintf("   - Candidates: %d\n", nrow(results$candidates)))
    cat(sprintf("   - Recurrence columns: %d\n", ncol(results$recurrence)))
    cat(sprintf("   - Prioritization results: %d\n", nrow(results$prioritization)))
    
}, error = function(e) {
    cat("❌ hdps() function failed:\n")
    cat("   Error:", e$message, "\n")
})

cat("\n")

# Test 2: 3-step workflow
cat("Test 2: 3-step workflow\n")
cat("----------------------\n")

tryCatch({
    # Step 1: Identify candidates
    candidates <- identify_candidates(dx, "pid", "icd9code", "dx", n = 50, min_patients = 5)
    cat("✅ identify_candidates() works\n")
    
    # Step 2: Assess recurrence
    recurrence <- assess_recurrence(candidates$data, "pid", "code", "dx")
    cat("✅ assess_recurrence() works\n")
    
    # Step 3: Prioritize
    cohort_data <- merge(recurrence, master, by = "pid", all.x = TRUE)
    prioritization <- prioritize(cohort_data, "pid", "exposure", "outcome")
    cat("✅ prioritize() works\n")
    
    cat(sprintf("   - Candidates: %d\n", nrow(candidates$candidates)))
    cat(sprintf("   - Recurrence columns: %d\n", ncol(recurrence)))
    cat(sprintf("   - Prioritization results: %d\n", nrow(prioritization)))
    
}, error = function(e) {
    cat("❌ 3-step workflow failed:\n")
    cat("   Error:", e$message, "\n")
})

cat("\n")

# Test 3: Plotting functions
cat("Test 3: Plotting functions\n")
cat("--------------------------\n")

tryCatch({
    if (exists("prioritization")) {
        # Test bias distribution plot
        p1 <- plot_bias_distribution(prioritization, top_n = 10)
        cat("✅ plot_bias_distribution() works\n")
        
        # Test covariate strength plot
        p2 <- plot_covariate_strength(prioritization)
        cat("✅ plot_covariate_strength() works\n")
        
        # Test bias vs prevalence plot
        p3 <- plot_bias_vs_prevalence(prioritization)
        cat("✅ plot_bias_vs_prevalence() works\n")
        
    } else {
        cat("⚠️  Skipping plot tests (no prioritization results)\n")
    }
    
}, error = function(e) {
    cat("❌ Plotting functions failed:\n")
    cat("   Error:", e$message, "\n")
})

cat("\n")

# Test 4: Interactive app
cat("Test 4: Interactive app\n")
cat("----------------------\n")

tryCatch({
    # Just test if the function exists and can be called
    if (exists("hdps_interactive")) {
        cat("✅ hdps_interactive() function exists\n")
        cat("   (Interactive app not launched in test mode)\n")
    } else {
        cat("⚠️  hdps_interactive() function not found\n")
    }
    
}, error = function(e) {
    cat("❌ Interactive app test failed:\n")
    cat("   Error:", e$message, "\n")
})

cat("\n=== Test Complete ===\n")
cat("All core functions have been tested.\n")
