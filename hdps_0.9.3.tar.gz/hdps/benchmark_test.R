#!/usr/bin/env Rscript
# Performance Benchmark: data.table vs Pure R Parallel Processing
# Testing different approaches for HDPS bias estimation

library(data.table)
library(parallel)
library(microbenchmark)

# Set up test data
set.seed(123)
n_patients <- 10000
n_codes <- 500
n_covariates <- 100

# Create synthetic dataset
test_data <- data.table(
    pid = rep(1:n_patients, each = sample(1:10, n_patients, replace = TRUE)),
    code = sample(1:n_codes, sum(sample(1:10, n_patients, replace = TRUE)), replace = TRUE)
)

# Create master data with exposure and outcome
master_data <- data.table(
    pid = 1:n_patients,
    exposure = rbinom(n_patients, 1, 0.3),
    outcome = rbinom(n_patients, 1, 0.2)
)

# Prepare cohort data (simulate HDPS workflow)
candidates <- test_data[, .(count = .N), by = code][count >= 10][1:n_covariates]
cohort_data <- merge(test_data[code %in% candidates$code], master_data, by = "pid", all.x = TRUE)
cohort_data[, code := paste0("dx_", code)]

# Create recurrence patterns (simplified)
recurrence_data <- dcast(cohort_data, pid ~ code, fun.aggregate = length, fill = 0)
cohort_data <- merge(recurrence_data, master_data, by = "pid", all.x = TRUE)

cat("=== HDPS Performance Benchmark ===\n")
cat(sprintf("Dataset: %d patients, %d covariates\n", n_patients, n_covariates))
cat(sprintf("Available cores: %d\n", detectCores()))
cat("\n")

# Method 1: Pure data.table approach (current)
estBias_datatable <- function(hdpsCohort, cova, expo, outc, correction = TRUE) {
    setDT(hdpsCohort)
    
    e1 <- hdpsCohort[get(expo) == 1, .N]
    e0 <- hdpsCohort[get(expo) == 0, .N]
    d1 <- hdpsCohort[get(outc) == 1, .N]
    d0 <- hdpsCohort[get(outc) == 0, .N]
    n <- hdpsCohort[, .N]
    
    # Create 2x2 tables
    expo_table <- hdpsCohort[, .(count = .N), by = .(get(expo), get(cova))]
    outc_table <- hdpsCohort[, .(count = .N), by = .(get(outc), get(cova))]
    
    # Extract counts
    e0c1 <- expo_table[get == 0 & get.1 == 1, count] %||% 0
    e1c1 <- expo_table[get == 1 & get.1 == 1, count] %||% 0
    e0c0 <- expo_table[get == 0 & get.1 == 0, count] %||% 0
    e1c0 <- expo_table[get == 1 & get.1 == 0, count] %||% 0
    
    d0c1 <- outc_table[get == 0 & get.1 == 1, count] %||% 0
    d1c1 <- outc_table[get == 1 & get.1 == 1, count] %||% 0
    d0c0 <- outc_table[get == 0 & get.1 == 0, count] %||% 0
    d1c0 <- outc_table[get == 1 & get.1 == 0, count] %||% 0
    
    c1 <- e1c1 + e0c1
    c0 <- e1c0 + e0c0
    
    # Apply correction
    if (correction) {
        if (e0c1 == 0 | e1c1 == 0 | e0c0 == 0 | e1c0 == 0) {
            e0c1 <- e0c1 + 0.1
            e1c1 <- e1c1 + 0.1
            e0c0 <- e0c0 + 0.1
            e1c0 <- e1c0 + 0.1
        }
        if (d0c1 == 0 | d1c1 == 0 | d0c0 == 0 | d1c0 == 0) {
            d0c1 <- d0c1 + 0.1
            d1c1 <- d1c1 + 0.1
            d0c0 <- d0c0 + 0.1
            d1c0 <- d1c0 + 0.1
        }
    }
    
    # Calculate bias
    pc1 <- c1 / n
    pc0 <- c0 / n
    rrCE <- ifelse((e1c1 / c1) / (e1c0 / c0) == 0, NA, (e1c1 / c1) / (e1c0 / c0))
    rrCD <- ifelse((d1c1 / c1) / (d1c0 / c0) == 0, NA, (d1c1 / c1) / (d1c0 / c0))
    
    bias <- (pc1 * (rrCD - 1) + 1) / (pc0 * (rrCD - 1) + 1)
    absLogBias <- abs(log(bias))
    
    data.table(code = cova, bias = bias, absLogBias = absLogBias)
}

# Method 2: Pure R with base functions
estBias_base_r <- function(hdpsCohort, cova, expo, outc, correction = TRUE) {
    # Convert to data.frame for base R operations
    df <- as.data.frame(hdpsCohort)
    
    e1 <- sum(df[[expo]] == 1, na.rm = TRUE)
    e0 <- sum(df[[expo]] == 0, na.rm = TRUE)
    d1 <- sum(df[[outc]] == 1, na.rm = TRUE)
    d0 <- sum(df[[outc]] == 0, na.rm = TRUE)
    n <- nrow(df)
    
    # Create contingency tables using base R
    expo_table <- table(df[[expo]], df[[cova]])
    outc_table <- table(df[[outc]], df[[cova]])
    
    # Extract counts
    e0c1 <- ifelse(nrow(expo_table) >= 1 && ncol(expo_table) >= 2, expo_table[1, 2], 0)
    e1c1 <- ifelse(nrow(expo_table) >= 2 && ncol(expo_table) >= 2, expo_table[2, 2], 0)
    e0c0 <- ifelse(nrow(expo_table) >= 1 && ncol(expo_table) >= 1, expo_table[1, 1], 0)
    e1c0 <- ifelse(nrow(expo_table) >= 2 && ncol(expo_table) >= 1, expo_table[2, 1], 0)
    
    d0c1 <- ifelse(nrow(outc_table) >= 1 && ncol(outc_table) >= 2, outc_table[1, 2], 0)
    d1c1 <- ifelse(nrow(outc_table) >= 2 && ncol(outc_table) >= 2, outc_table[2, 2], 0)
    d0c0 <- ifelse(nrow(outc_table) >= 1 && ncol(outc_table) >= 1, outc_table[1, 1], 0)
    d1c0 <- ifelse(nrow(outc_table) >= 2 && ncol(outc_table) >= 1, outc_table[2, 1], 0)
    
    c1 <- e1c1 + e0c1
    c0 <- e1c0 + e0c0
    
    # Apply correction
    if (correction) {
        if (e0c1 == 0 | e1c1 == 0 | e0c0 == 0 | e1c0 == 0) {
            e0c1 <- e0c1 + 0.1
            e1c1 <- e1c1 + 0.1
            e0c0 <- e0c0 + 0.1
            e1c0 <- e1c0 + 0.1
        }
        if (d0c1 == 0 | d1c1 == 0 | d0c0 == 0 | d1c0 == 0) {
            d0c1 <- d0c1 + 0.1
            d1c1 <- d1c1 + 0.1
            d0c0 <- d0c0 + 0.1
            d1c0 <- d1c0 + 0.1
        }
    }
    
    # Calculate bias
    pc1 <- c1 / n
    pc0 <- c0 / n
    rrCE <- ifelse((e1c1 / c1) / (e1c0 / c0) == 0, NA, (e1c1 / c1) / (e1c0 / c0))
    rrCD <- ifelse((d1c1 / c1) / (d1c0 / c0) == 0, NA, (d1c1 / c1) / (d1c0 / c0))
    
    bias <- (pc1 * (rrCD - 1) + 1) / (pc0 * (rrCD - 1) + 1)
    absLogBias <- abs(log(bias))
    
    data.frame(code = cova, bias = bias, absLogBias = absLogBias)
}

# Method 3: Optimized data.table with vectorized operations
estBias_optimized_dt <- function(hdpsCohort, cova, expo, outc, correction = TRUE) {
    setDT(hdpsCohort)
    
    # Pre-calculate totals
    e1 <- sum(hdpsCohort[[expo]] == 1, na.rm = TRUE)
    e0 <- sum(hdpsCohort[[expo]] == 0, na.rm = TRUE)
    d1 <- sum(hdpsCohort[[outc]] == 1, na.rm = TRUE)
    d0 <- sum(hdpsCohort[[outc]] == 0, na.rm = TRUE)
    n <- nrow(hdpsCohort)
    
    # Single pass contingency tables
    expo_table <- table(hdpsCohort[[expo]], hdpsCohort[[cova]], useNA = "no")
    outc_table <- table(hdpsCohort[[outc]], hdpsCohort[[cova]], useNA = "no")
    
    # Vectorized count extraction
    e0c1 <- ifelse(nrow(expo_table) >= 1 && ncol(expo_table) >= 2, expo_table[1, 2], 0)
    e1c1 <- ifelse(nrow(expo_table) >= 2 && ncol(expo_table) >= 2, expo_table[2, 2], 0)
    e0c0 <- ifelse(nrow(expo_table) >= 1 && ncol(expo_table) >= 1, expo_table[1, 1], 0)
    e1c0 <- ifelse(nrow(expo_table) >= 2 && ncol(expo_table) >= 1, expo_table[2, 1], 0)
    
    d0c1 <- ifelse(nrow(outc_table) >= 1 && ncol(outc_table) >= 2, outc_table[1, 2], 0)
    d1c1 <- ifelse(nrow(outc_table) >= 2 && ncol(outc_table) >= 2, outc_table[2, 2], 0)
    d0c0 <- ifelse(nrow(outc_table) >= 1 && ncol(outc_table) >= 1, outc_table[1, 1], 0)
    d1c0 <- ifelse(nrow(outc_table) >= 2 && ncol(outc_table) >= 1, outc_table[2, 1], 0)
    
    c1 <- e1c1 + e0c1
    c0 <- e1c0 + e0c0
    
    # Apply correction
    if (correction) {
        if (e0c1 == 0 | e1c1 == 0 | e0c0 == 0 | e1c0 == 0) {
            e0c1 <- e0c1 + 0.1
            e1c1 <- e1c1 + 0.1
            e0c0 <- e0c0 + 0.1
            e1c0 <- e1c0 + 0.1
        }
        if (d0c1 == 0 | d1c1 == 0 | d0c0 == 0 | d1c0 == 0) {
            d0c1 <- d0c1 + 0.1
            d1c1 <- d1c1 + 0.1
            d0c0 <- d0c0 + 0.1
            d1c0 <- d1c0 + 0.1
        }
    }
    
    # Calculate bias
    pc1 <- c1 / n
    pc0 <- c0 / n
    rrCE <- ifelse((e1c1 / c1) / (e1c0 / c0) == 0, NA, (e1c1 / c1) / (e1c0 / c0))
    rrCD <- ifelse((d1c1 / c1) / (d1c0 / c0) == 0, NA, (d1c1 / c1) / (d1c0 / c0))
    
    bias <- (pc1 * (rrCD - 1) + 1) / (pc0 * (rrCD - 1) + 1)
    absLogBias <- abs(log(bias))
    
    data.table(code = cova, bias = bias, absLogBias = absLogBias)
}

# Test single covariate performance
cat("=== Single Covariate Performance ===\n")
test_cova <- names(cohort_data)[3]  # First covariate

# Benchmark single covariate
benchmark_single <- microbenchmark(
    "data.table" = estBias_datatable(cohort_data, test_cova, "exposure", "outcome"),
    "base_R" = estBias_base_r(cohort_data, test_cova, "exposure", "outcome"),
    "optimized_dt" = estBias_optimized_dt(cohort_data, test_cova, "exposure", "outcome"),
    times = 100
)

print(benchmark_single)

# Test multiple covariates performance
cat("\n=== Multiple Covariates Performance ===\n")
covariates <- names(cohort_data)[3:min(13, ncol(cohort_data))]  # Test 10 covariates

# Method 1: Sequential data.table
prioritize_datatable <- function(dt, covariates, expo, outc) {
    rbindlist(lapply(covariates, function(x) {
        estBias_datatable(dt, x, expo, outc)
    }))
}

# Method 2: Sequential base R
prioritize_base_r <- function(dt, covariates, expo, outc) {
    results <- lapply(covariates, function(x) {
        estBias_base_r(dt, x, expo, outc)
    })
    do.call(rbind, results)
}

# Method 3: Parallel data.table
prioritize_parallel_dt <- function(dt, covariates, expo, outc, n_cores = 4) {
    cl <- makeCluster(n_cores)
    clusterExport(cl, c("estBias_datatable", "setDT", ".N"), envir = environment())
    
    results <- parLapply(cl, covariates, function(x) {
        estBias_datatable(dt, x, expo, outc)
    })
    
    stopCluster(cl)
    rbindlist(results)
}

# Method 4: Parallel base R
prioritize_parallel_base <- function(dt, covariates, expo, outc, n_cores = 4) {
    cl <- makeCluster(n_cores)
    clusterExport(cl, c("estBias_base_r"), envir = environment())
    
    results <- parLapply(cl, covariates, function(x) {
        estBias_base_r(dt, x, expo, outc)
    })
    
    stopCluster(cl)
    do.call(rbind, results)
}

# Method 5: Optimized data.table sequential
prioritize_optimized_dt <- function(dt, covariates, expo, outc) {
    rbindlist(lapply(covariates, function(x) {
        estBias_optimized_dt(dt, x, expo, outc)
    }))
}

# Method 6: Optimized data.table parallel
prioritize_optimized_parallel <- function(dt, covariates, expo, outc, n_cores = 4) {
    cl <- makeCluster(n_cores)
    clusterExport(cl, c("estBias_optimized_dt", "setDT"), envir = environment())
    
    results <- parLapply(cl, covariates, function(x) {
        estBias_optimized_dt(dt, x, expo, outc)
    })
    
    stopCluster(cl)
    rbindlist(results)
}

# Benchmark multiple covariates
benchmark_multiple <- microbenchmark(
    "data.table_seq" = prioritize_datatable(cohort_data, covariates, "exposure", "outcome"),
    "base_R_seq" = prioritize_base_r(cohort_data, covariates, "exposure", "outcome"),
    "data.table_parallel" = prioritize_parallel_dt(cohort_data, covariates, "exposure", "outcome"),
    "base_R_parallel" = prioritize_parallel_base(cohort_data, covariates, "exposure", "outcome"),
    "optimized_dt_seq" = prioritize_optimized_dt(cohort_data, covariates, "exposure", "outcome"),
    "optimized_dt_parallel" = prioritize_optimized_parallel(cohort_data, covariates, "exposure", "outcome"),
    times = 10
)

print(benchmark_multiple)

# Memory usage test
cat("\n=== Memory Usage Test ===\n")
memory_test <- function() {
    gc()
    start_memory <- gc()[, 2]
    
    # Test each method
    methods <- list(
        "data.table_seq" = function() prioritize_datatable(cohort_data, covariates, "exposure", "outcome"),
        "base_R_seq" = function() prioritize_base_r(cohort_data, covariates, "exposure", "outcome"),
        "optimized_dt_seq" = function() prioritize_optimized_dt(cohort_data, covariates, "exposure", "outcome")
    )
    
    for (method_name in names(methods)) {
        gc()
        method()
        end_memory <- gc()[, 2]
        memory_used <- end_memory - start_memory
        cat(sprintf("%s: %.1f MB\n", method_name, memory_used))
    }
}

memory_test()

cat("\n=== Performance Summary ===\n")
cat("Based on the benchmark results, the optimal approach will be recommended.\n")
cat("Key factors to consider:\n")
cat("- Speed: data.table operations vs base R\n")
cat("- Parallel efficiency: overhead vs speedup\n")
cat("- Memory usage: data.table vs base R\n")
cat("- Code maintainability: complexity vs performance\n")
