#!/usr/bin/env Rscript
# Test the optimized HDPS package without copy() operations

library(hdps)
library(data.table)

# Load test data
data(dx)
data(master)

cat("Testing HDPS package without copy() operations...\n\n")

# Test the optimized hdps function
cat("Test: hdps() function without copy()\n")
cat("===================================\n")

start_time <- Sys.time()
start_memory <- gc()[, 2]

results <- hdps(
    data = dx,
    id_col = "pid",
    code_col = "icd9code", 
    exposure_col = "exposure",
    outcome_col = "outcome",
    master_data = master,
    n_candidates = 100,
    min_patients = 5,
    n_cores = 1  # Use single core for testing
)

end_time <- Sys.time()
end_memory <- gc()[, 2]

duration <- as.numeric(difftime(end_time, start_time, units = "secs"))
memory_used <- end_memory - start_memory

cat("✅ hdps() function works without copy()\n")
cat(sprintf("   - Duration: %.2f seconds\n", duration))
cat(sprintf("   - Memory used: %.1f MB\n", memory_used))
cat(sprintf("   - Candidates: %d\n", nrow(results$candidates)))
cat(sprintf("   - Recurrence columns: %d\n", ncol(results$recurrence)))
cat(sprintf("   - Prioritization results: %d\n", nrow(results$prioritization)))
cat(sprintf("   - Processing rate: %.0f covariates/second\n", 
            nrow(results$prioritization) / duration))

# Test that original data is not modified
cat("\nTest: Original data integrity\n")
cat("=============================\n")

# Check if original data is unchanged
original_dx_names <- names(dx)
original_master_names <- names(master)

cat(sprintf("   - Original dx columns: %s\n", paste(original_dx_names, collapse = ", ")))
cat(sprintf("   - Original master columns: %s\n", paste(original_master_names, collapse = ", ")))

# Check if any columns were renamed
if (all(original_dx_names == names(dx)) && all(original_master_names == names(master))) {
    cat("✅ Original data is unchanged - no copy() needed!\n")
} else {
    cat("❌ Original data was modified\n")
}

cat("\n=== Performance Benefits ===\n")
cat("Key optimizations implemented:\n")
cat("1. Use column references (get()) instead of setnames()\n")
cat("2. Create new data.tables instead of copying and renaming\n")
cat("3. Avoid expensive copy() operations for large datasets\n")
cat("4. Maintain original data integrity\n")
cat("5. Significant memory and time savings for large datasets\n")
